
from django.contrib import admin
from .models import deliverydatabase,deliveryadmin

admin.site.register(deliverydatabase,deliveryadmin)